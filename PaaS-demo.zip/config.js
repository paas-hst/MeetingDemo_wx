/**
 * 小程序配置文件
 */
var config = {
  webrtcServerUrl: 'https://fspwxlite.haoshitong.com:8443/weapp/webrtc_room',
  socketUrl: 'wss://fspwxlite.haoshitong.com:8080'
}

module.exports = config;
